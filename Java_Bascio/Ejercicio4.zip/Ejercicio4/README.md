Ejercicio

Crear una clase SmartDevice
Crear las clases hijas:
    SmartPhone
    SmartWatch

Agregar atributos tal cual tendrías esos objetos en la realidad.
Crear constructores vacios y con los parametros

Desde un Main: Crear Objetos de cada una y utilizarlos para imprimir sus valores por consola.